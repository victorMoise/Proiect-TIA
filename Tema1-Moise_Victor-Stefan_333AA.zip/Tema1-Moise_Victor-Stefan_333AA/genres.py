genres = ["Star Wars", "LEGO City", "Technic", "Friends", "Harry Potter", "Marvel Super Heroes"]
genre_popularity = {
    "Star Wars": 1.3,
    "LEGO City": 1.0,
    "Technic": 0.8,
    "Friends": 0.9,
    "Harry Potter": 1.1,
    "Marvel Super Heroes": 1.2,
}